'use client';

import { useMemo, useRef, useState } from 'react';
import type { ChangeEvent, PointerEvent as ReactPointerEvent } from 'react';
import { CheckCircle2, Lock, Move, RotateCcw, Save, SlidersHorizontal, Sparkles, Users } from 'lucide-react';
import type { AnalysisResult, PositionCode, TacticalStyle } from '@/lib/analyzer';
import { FormationRoleLabPanel as LegacyFormationRoleLabPanel } from '@/components/FormationRoleLabPanel';
import {
  FORMATION_BLUEPRINTS,
  FORMATION_ROLE_CATALOG,
  buildFormationLineup,
  getFormationBlueprint,
  type FormationBlueprint,
  type FormationRoleId,
  type FormationSlot
} from '@/lib/formationRoleEngine';
import { readAccountStorage, writeAccountStorage } from '@/lib/accountStorage';
import { createStableId } from '@/lib/stableId';

const STORAGE_KEY = 'buildmaster_custom_formations_v31_10';
const LAST_EDITOR_KEY = 'buildmaster_free_formation_editor_v4080';

const POSITION_LABELS: Record<PositionCode, string> = {
  CF: 'CA', SS: 'SA', LWF: 'PE', RWF: 'PD', LMF: 'ME', RMF: 'MD',
  AMF: 'MAT', CMF: 'MLG', DMF: 'VOL', CB: 'ZAG', LB: 'LE', RB: 'LD', GK: 'GOL'
};

const POSITION_OPTIONS: PositionCode[] = ['CF','SS','LWF','RWF','AMF','LMF','RMF','CMF','DMF','LB','CB','RB'];

type SavedCustomFormation = FormationBlueprint & { createdAt: string; updatedAt: string };

type DraftSnapshot = {
  baseId: string;
  formation: FormationBlueprint;
};

function cloneFormation(source: FormationBlueprint): FormationBlueprint {
  return {
    ...source,
    family: 'personalizada',
    slots: source.slots.map((slot) => ({
      ...slot,
      alternatives: [...slot.alternatives],
      primaryRoles: [...slot.primaryRoles],
      complementaryRoles: [...slot.complementaryRoles],
      keyTraits: [...slot.keyTraits]
    }))
  };
}

function lineForPosition(position: PositionCode): FormationSlot['line'] {
  if (position === 'GK') return 'goleiro';
  if (['LB','CB','RB'].includes(position)) return 'defesa';
  if (['CF','SS','LWF','RWF'].includes(position)) return 'ataque';
  return 'meio';
}

function alternativesForPosition(position: PositionCode): PositionCode[] {
  const alternatives: Partial<Record<PositionCode, PositionCode[]>> = {
    CF:['SS'], SS:['CF','AMF','LWF','RWF'], LWF:['SS','LMF'], RWF:['SS','RMF'],
    AMF:['SS','CMF'], LMF:['LWF','CMF'], RMF:['RWF','CMF'], CMF:['AMF','DMF','LMF','RMF'],
    DMF:['CMF'], LB:['LMF','CB'], RB:['RMF','CB'], CB:['LB','RB'], GK:[]
  };
  return [...(alternatives[position] ?? [])];
}

function rolesForPosition(position: PositionCode): FormationRoleId[] {
  return Object.values(FORMATION_ROLE_CATALOG)
    .filter((role) => role.positions.includes(position) || role.usablePositions?.includes(position))
    .map((role) => role.id);
}

function labelForPosition(position: PositionCode, x: number): string {
  const side = x < 43 ? ' E' : x > 57 ? ' D' : '';
  if (position === 'CF') return `CA${side}`;
  if (position === 'SS') return `SA${side}`;
  if (position === 'CMF') return `MLG${side}`;
  if (position === 'DMF') return `VOL${side}`;
  if (position === 'CB') return x < 43 ? 'ZAG E' : x > 57 ? 'ZAG D' : 'ZAG C';
  return POSITION_LABELS[position];
}

function inferPosition(x: number, y: number, current: PositionCode): PositionCode {
  if (current === 'GK') return 'GK';
  if (y >= 68) {
    if (x <= 22) return 'LB';
    if (x >= 78) return 'RB';
    return 'CB';
  }
  if (y >= 48) {
    if (x <= 16) return 'LMF';
    if (x >= 84) return 'RMF';
    return y >= 57 ? 'DMF' : 'CMF';
  }
  if (y >= 29) {
    if (x <= 16) return 'LMF';
    if (x >= 84) return 'RMF';
    return 'AMF';
  }
  if (x <= 18) return 'LWF';
  if (x >= 82) return 'RWF';
  if (x >= 38 && x <= 62 && y <= 18) return 'CF';
  return 'SS';
}

function snappedCoordinates(position: PositionCode, currentX: number): { x: number; y: number } {
  const centralX = Math.max(24, Math.min(76, currentX));
  const map: Record<PositionCode, { x: number; y: number }> = {
    CF:{x:Math.max(34,Math.min(66,currentX)),y:14}, SS:{x:centralX,y:23},
    LWF:{x:10,y:19}, RWF:{x:90,y:19}, AMF:{x:centralX,y:37},
    LMF:{x:12,y:49}, RMF:{x:88,y:49}, CMF:{x:centralX,y:51}, DMF:{x:centralX,y:61},
    LB:{x:10,y:73}, RB:{x:90,y:73}, CB:{x:Math.max(28,Math.min(72,currentX)),y:79}, GK:{x:50,y:93}
  };
  return map[position];
}

function normalizeSlot(slot: FormationSlot, position: PositionCode, x: number, y: number): FormationSlot {
  const compatible = rolesForPosition(position);
  const currentPrimary = slot.primaryRoles.find((role) => compatible.includes(role));
  const primary = currentPrimary ?? compatible[0] ?? slot.primaryRoles[0];
  const complementary = compatible.filter((role) => role !== primary).slice(0, 4);
  return {
    ...slot,
    position,
    x: Math.max(5, Math.min(95, Math.round(x * 10) / 10)),
    y: position === 'GK' ? 93 : Math.max(7, Math.min(88, Math.round(y * 10) / 10)),
    label: labelForPosition(position, x),
    line: lineForPosition(position),
    alternatives: alternativesForPosition(position),
    primaryRoles: primary ? [primary] : slot.primaryRoles,
    complementaryRoles: complementary
  };
}

function attackDescription(slots: FormationSlot[]): string {
  const counts = new Map<PositionCode, number>();
  for (const slot of slots.filter((item) => item.line === 'ataque')) counts.set(slot.position, (counts.get(slot.position) ?? 0) + 1);
  const order: PositionCode[] = ['LWF','SS','CF','RWF'];
  const pieces = order.flatMap((position) => {
    const count = counts.get(position) ?? 0;
    if (!count) return [];
    return [`${count > 1 ? `${count} ` : ''}${POSITION_LABELS[position]}`];
  });
  return pieces.join(' + ') || 'ataque personalizado';
}

function inferFormationName(slots: FormationSlot[]): string {
  const field = slots.filter((slot) => slot.position !== 'GK');
  const defenders = field.filter((slot) => slot.y >= 68).length;
  const deepMid = field.filter((slot) => slot.y >= 53 && slot.y < 68).length;
  const advancedMid = field.filter((slot) => slot.y >= 29 && slot.y < 53).length;
  const attackers = field.filter((slot) => slot.y < 29).length;
  const numbers = [defenders, deepMid, advancedMid, attackers].filter((value) => value > 0);
  const structure = numbers.join('-');
  return `${structure || 'Personalizada'} • ${attackDescription(slots)}`;
}

function readSavedSnapshot(): DraftSnapshot | null {
  try {
    const parsed = JSON.parse(readAccountStorage(LAST_EDITOR_KEY) || 'null') as DraftSnapshot | null;
    if (!parsed?.baseId || !parsed.formation?.slots?.length) return null;
    return parsed;
  } catch {
    return null;
  }
}

function initialBaseId(activeFormation: string): string {
  if (activeFormation !== 'AUTO' && FORMATION_BLUEPRINTS.some((item) => item.id === activeFormation)) return activeFormation;
  return FORMATION_BLUEPRINTS.some((item) => item.id === '4-3-3-2ss') ? '4-3-3-2ss' : FORMATION_BLUEPRINTS[0]?.id ?? '4-3-3';
}

function persistCustomFormation(formation: FormationBlueprint): SavedCustomFormation {
  const now = new Date().toISOString();
  const saved: SavedCustomFormation = {
    ...cloneFormation(formation),
    id: createStableId('custom-formation-free'),
    name: inferFormationName(formation.slots),
    description: `Formação livre criada no editor v40.80 a partir de ${formation.name}.`,
    createdAt: now,
    updatedAt: now
  };
  let current: SavedCustomFormation[] = [];
  try {
    const parsed = JSON.parse(readAccountStorage(STORAGE_KEY) || '[]');
    current = Array.isArray(parsed) ? parsed : [];
  } catch {
    current = [];
  }
  writeAccountStorage(STORAGE_KEY, JSON.stringify([saved, ...current].slice(0, 40)));
  return saved;
}

export function FormationRoleLabPanelV4080({ results, activeFormation, activeStyle }: { results: AnalysisResult[]; activeFormation: string; activeStyle: TacticalStyle }) {
  const remembered = useMemo(readSavedSnapshot, []);
  const fallbackBase = initialBaseId(activeFormation);
  const initialBase = remembered && FORMATION_BLUEPRINTS.some((item) => item.id === remembered.baseId) ? remembered.baseId : fallbackBase;
  const [baseId, setBaseId] = useState(initialBase);
  const [draft, setDraft] = useState<FormationBlueprint>(() => remembered?.formation ? cloneFormation(remembered.formation) : cloneFormation(getFormationBlueprint(initialBase)));
  const [autoPosition, setAutoPosition] = useState(true);
  const [selectedSlotId, setSelectedSlotId] = useState<string>(() => draft.slots.find((slot) => slot.position !== 'GK')?.id ?? draft.slots[0]?.id ?? '');
  const [draggingId, setDraggingId] = useState<string | null>(null);
  const [message, setMessage] = useState('Arraste um jogador no campo. A posição e a estrutura serão recalculadas automaticamente.');
  const [legacyRevision, setLegacyRevision] = useState(0);
  const pitchRef = useRef<HTMLElement | null>(null);

  const inferredName = useMemo(() => inferFormationName(draft.slots), [draft.slots]);
  const lineup = useMemo(() => buildFormationLineup(results, { ...draft, name: inferredName }), [draft, inferredName, results]);
  const selectedSlot = draft.slots.find((slot) => slot.id === selectedSlotId) ?? draft.slots[0] ?? null;

  function commitSlots(nextSlots: FormationSlot[], nextMessage?: string) {
    const next = { ...draft, name: inferFormationName(nextSlots), slots: nextSlots };
    setDraft(next);
    writeAccountStorage(LAST_EDITOR_KEY, JSON.stringify({ baseId, formation: next } satisfies DraftSnapshot));
    if (nextMessage) setMessage(nextMessage);
  }

  function updateSlotPosition(slotId: string, position: PositionCode, snap = true) {
    const nextSlots = draft.slots.map((slot) => {
      if (slot.id !== slotId) return slot;
      if (slot.position === 'GK' && position !== 'GK') return slot;
      const coords = snap ? snappedCoordinates(position, slot.x) : { x: slot.x, y: slot.y };
      return normalizeSlot(slot, position, coords.x, coords.y);
    });
    commitSlots(nextSlots, `${labelForPosition(position, nextSlots.find((item) => item.id === slotId)?.x ?? 50)} aplicado. O encaixe do elenco foi recalculado.`);
  }

  function handlePointerMove(slotId: string, event: ReactPointerEvent<HTMLButtonElement>) {
    if (draggingId !== slotId || !pitchRef.current) return;
    const source = draft.slots.find((slot) => slot.id === slotId);
    if (!source || source.position === 'GK') return;
    const rect = pitchRef.current.getBoundingClientRect();
    const x = Math.max(5, Math.min(95, ((event.clientX - rect.left) / rect.width) * 100));
    const y = Math.max(7, Math.min(88, ((event.clientY - rect.top) / rect.height) * 100));
    const nextPosition = autoPosition ? inferPosition(x, y, source.position) : source.position;
    const nextSlots = draft.slots.map((slot) => slot.id === slotId ? normalizeSlot(slot, nextPosition, x, y) : slot);
    commitSlots(nextSlots);
  }

  function startDrag(slot: FormationSlot, event: ReactPointerEvent<HTMLButtonElement>) {
    setSelectedSlotId(slot.id);
    if (slot.position === 'GK') {
      setMessage('O goleiro fica protegido para não virar jogador de linha por acidente.');
      return;
    }
    event.currentTarget.setPointerCapture(event.pointerId);
    setDraggingId(slot.id);
  }

  function endDrag(slotId: string, event: ReactPointerEvent<HTMLButtonElement>) {
    if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
    setDraggingId(null);
    const slot = draft.slots.find((item) => item.id === slotId);
    if (slot) setMessage(`${slot.label} agora atua como ${POSITION_LABELS[slot.position]}. Formação: ${inferFormationName(draft.slots)}.`);
  }

  function selectBase(nextBaseId: string) {
    const next = cloneFormation(getFormationBlueprint(nextBaseId));
    setBaseId(nextBaseId);
    setDraft(next);
    setSelectedSlotId(next.slots.find((slot) => slot.position !== 'GK')?.id ?? next.slots[0]?.id ?? '');
    writeAccountStorage(LAST_EDITOR_KEY, JSON.stringify({ baseId: nextBaseId, formation: next } satisfies DraftSnapshot));
    setMessage(`Base ${next.name} carregada. Agora mova os jogadores como no eFootball.`);
  }

  function restoreBase() {
    selectBase(baseId);
    setMessage('Posições restauradas para a formação base.');
  }

  function saveFormation() {
    const saved = persistCustomFormation({ ...draft, name: inferredName });
    setLegacyRevision((value) => value + 1);
    setMessage(`Formação salva: ${saved.name}. Ela já pode ser usada pelas ferramentas de montagem e encaixe.`);
  }

  return (
    <section className="bm4080-free-formation-shell">
      <article className="bm4080-free-formation-editor luxury-panel">
        <header className="bm4080-free-formation-header">
          <div>
            <p className="kicker"><Sparkles size={15}/> Editor livre estilo eFootball</p>
            <h3>Arraste os jogadores e transforme a formação</h3>
            <p>Comece por uma formação pronta e reposicione cada jogador. PE/PD podem virar SA, CA pode recuar para SA, MAT pode virar MLG/VOL e a estrutura é renomeada automaticamente.</p>
          </div>
          <strong>{inferredName}</strong>
        </header>

        <div className="bm4080-free-formation-controls">
          <label><span>Formação base</span><select value={baseId} onChange={(event: ChangeEvent<HTMLSelectElement>) => selectBase(event.target.value)}>{FORMATION_BLUEPRINTS.map((formation) => <option key={formation.id} value={formation.id}>{formation.name}</option>)}</select></label>
          <label className="bm4080-auto-position"><input type="checkbox" checked={autoPosition} onChange={(event) => setAutoPosition(event.target.checked)}/><span><b>Posição automática</b><small>Ao arrastar, o app muda PE → SA → CA conforme a região.</small></span></label>
          <button type="button" onClick={restoreBase}><RotateCcw size={16}/> Restaurar base</button>
          <button type="button" className="elite-button" onClick={saveFormation}><Save size={16}/> Salvar personalizada</button>
        </div>

        <div className="bm4080-free-formation-grid">
          <article ref={pitchRef} className="bm4080-free-pitch" aria-label={`Editor visual ${inferredName}`}>
            <div className="bm4080-free-pitch-lines" aria-hidden="true"><i/><i/><i/><i/></div>
            {draft.slots.map((slot) => {
              const pick = lineup.find((item) => item.slot.id === slot.id);
              return <button
                type="button"
                key={slot.id}
                className={`bm4080-free-marker ${selectedSlotId === slot.id ? 'selected' : ''} ${draggingId === slot.id ? 'dragging' : ''} ${slot.position === 'GK' ? 'locked' : ''}`}
                style={{ left:`${slot.x}%`, top:`${slot.y}%`, touchAction:'none' }}
                onPointerDown={(event) => startDrag(slot, event)}
                onPointerMove={(event) => handlePointerMove(slot.id, event)}
                onPointerUp={(event) => endDrag(slot.id, event)}
                onPointerCancel={(event) => endDrag(slot.id, event)}
                onClick={() => setSelectedSlotId(slot.id)}
                aria-label={`${slot.label}, ${POSITION_LABELS[slot.position]}${slot.position === 'GK' ? ', posição protegida' : ', arraste para reposicionar'}`}
              >
                <span>{slot.position === 'GK' ? <Lock size={13}/> : <Move size={13}/>} {slot.label}</span>
                <strong>{pick?.player?.parsed.playerName?.split(' ').slice(0,2).join(' ') ?? POSITION_LABELS[slot.position]}</strong>
                <small>{pick?.player ? `${pick.score}/100` : 'vaga'}</small>
              </button>;
            })}
          </article>

          <aside className="bm4080-free-inspector">
            <div className="bm4080-free-identity"><SlidersHorizontal size={18}/><div><span>Estrutura reconhecida</span><strong>{inferredName}</strong></div></div>
            {selectedSlot && <>
              <label><span>Jogador/slot</span><strong>{selectedSlot.label}</strong></label>
              <label><span>Posição manual</span><select value={selectedSlot.position} disabled={selectedSlot.position === 'GK'} onChange={(event: ChangeEvent<HTMLSelectElement>) => updateSlotPosition(selectedSlot.id, event.target.value as PositionCode)}>{selectedSlot.position === 'GK' ? <option value="GK">GOL</option> : POSITION_OPTIONS.map((position) => <option key={position} value={position}>{POSITION_LABELS[position]}</option>)}</select></label>
              <div className="bm4080-free-position-readout"><span>X <b>{Math.round(selectedSlot.x)}</b></span><span>Y <b>{Math.round(selectedSlot.y)}</b></span><span>Linha <b>{selectedSlot.line}</b></span></div>
              <p>{selectedSlot.position === 'GK' ? 'Goleiro protegido.' : 'Você pode arrastar no campo ou escolher a posição acima. As funções compatíveis também são atualizadas.'}</p>
            </>}
            <div className="bm4080-free-live-lineup"><h4><Users size={16}/> Encaixe ao vivo</h4>{lineup.filter((pick) => pick.slot.position !== 'GK').slice(0,10).map((pick) => <span key={pick.slot.id}><b>{pick.slot.label}</b>{pick.player?.parsed.playerName ?? 'vaga'}<em>{pick.score || 0}</em></span>)}</div>
          </aside>
        </div>

        <p className="bm4080-free-message" role="status"><CheckCircle2 size={15}/> {message}</p>
      </article>

      <details className="bm4080-advanced-formation-tools luxury-panel">
        <summary><div><span>Ferramentas táticas avançadas</span><strong>Técnicos, estilos, guia e montagem</strong></div><SlidersHorizontal size={18}/></summary>
        <LegacyFormationRoleLabPanel key={legacyRevision} results={results} activeFormation={activeFormation} activeStyle={activeStyle}/>
      </details>
    </section>
  );
}
