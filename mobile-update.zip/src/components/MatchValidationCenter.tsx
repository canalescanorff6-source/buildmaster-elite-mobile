'use client';

import { useEffect, useMemo, useState, type ChangeEvent } from 'react';
import { Activity, CheckCircle2, History, Save, Target, Trash2 } from 'lucide-react';
import { RealValidationV3760Panel } from '@/components/RealValidationV3760Panel';
import { RealGameplayValidationV4050Panel } from '@/components/RealGameplayValidationV4050Panel';
import { LongitudinalGameplayV4060Panel } from '@/components/LongitudinalGameplayV4060Panel';
import type { AnalysisResult } from '@/lib/analyzer';
import {
  MATCH_PROBLEM_TAGS,
  cardFingerprint,
  createMatchValidationRecord,
  createMatchSessionIdR462,
  summarizeMatchValidation,
  type MatchConnectionState,
  type MatchPerformanceMetrics,
  type MatchValidationMode,
  type MatchValidationRating,
  type MatchValidationRecord
} from '@/lib/appEvolution';
import { writeAccountStorage } from '@/lib/accountStorage';
import { buildMatchEvidenceLoop } from '@/lib/professionalIntelligenceV37';
import { buildRealValidationV3760, REAL_VALIDATION_PROFILE_STORAGE_KEY, type ControlStyleV3760 } from '@/lib/realValidationV3760';
import { buildRealGameplayValidationV4050, persistVerifiedGameplayWinnerV4050 } from '@/lib/realGameplayValidationV4050';
import { buildLongitudinalGameplayV4060, persistLongitudinalWinnerV4060 } from '@/lib/longitudinalGameplayLearningV4060';
import { buildMatchEvidenceCalibrationR136 } from '@/modules/matches/matchEvidenceCalibrationR136';
import { buildBuildOutcomeCalibrationR460 } from '@/modules/matches/buildOutcomeCalibrationR460';
import { analysisUsagePositionR138 } from '@/lib/analysisUsagePositionR138';
import {
  exactUsageMatchValidationRecordsR137,
  persistMatchValidationRepositoryR137,
  readMatchValidationRepositoryR137,
  removeUsageMatchValidationRecordsR137
} from '@/modules/matches/matchValidationRepositoryR137';

const RATING_OPTIONS: MatchValidationRating[] = [1, 2, 3, 4, 5];

function loadRecords(): MatchValidationRecord[] {
  return readMatchValidationRepositoryR137();
}

function RatingField({ label, value, onChange }: { label: string; value: MatchValidationRating; onChange: (value: MatchValidationRating) => void }) {
  return <label className="match-rating-field"><span>{label}</span><div>{RATING_OPTIONS.map((rating) => <button type="button" key={rating} className={value === rating ? 'selected' : ''} onClick={() => onChange(rating)}>{rating}</button>)}</div></label>;
}

function OptionalActionRatingField({ label, value, onChange }: { label: string; value?: MatchValidationRating; onChange: (value?: MatchValidationRating) => void }) {
  return <label className="match-rating-field"><span>{label}</span><div><button type="button" className={value == null ? 'selected' : ''} onClick={() => onChange(undefined)}>—</button>{RATING_OPTIONS.map((rating) => <button type="button" key={rating} className={value === rating ? 'selected' : ''} onClick={() => onChange(rating)}>{rating}</button>)}</div></label>;
}

function MetricField({ label, value, onChange }: { label: string; value: number; onChange: (value: number) => void }) {
  return <label className="match-metric-field"><span>{label}</span><input type="number" min={0} max={99} value={value} onChange={(event: ChangeEvent<HTMLInputElement>) => onChange(Math.max(0, Math.min(99, Number(event.target.value) || 0)))}/></label>;
}

const EMPTY_METRICS: MatchPerformanceMetrics = {
  goals: 0,
  assists: 0,
  passErrors: 0,
  tackles: 0,
  interceptions: 0,
  ballLosses: 0,
  dribblesCompleted: 0,
  shots: 0,
  saves: 0,
  goalsConceded: 0,
  clearances: 0,
  blocks: 0,
  aerialDuelsWon: 0,
  duelsWon: 0,
  recoveries: 0,
  progressivePasses: 0,
  keyPasses: 0,
  shotsOnTarget: 0,
  runsBehind: 0,
  successfulPressures: 0
};

export function MatchValidationCenter({ result }: { result: AnalysisResult }) {
  const [records, setRecords] = useState<MatchValidationRecord[]>([]);
  const [minutes, setMinutes] = useState(90);
  const [overallRating, setOverallRating] = useState<MatchValidationRating>(3);
  const [passing, setPassing] = useState<MatchValidationRating>(3);
  const [movement, setMovement] = useState<MatchValidationRating>(3);
  const [finishing, setFinishing] = useState<MatchValidationRating>(3);
  const [defending, setDefending] = useState<MatchValidationRating>(3);
  const [physical, setPhysical] = useState<MatchValidationRating>(3);
  const [stamina, setStamina] = useState<MatchValidationRating>(3);
  const [tags, setTags] = useState<string[]>([]);
  const [note, setNote] = useState('');
  const [message, setMessage] = useState('');
  const [mode, setMode] = useState<MatchValidationMode>('ranked');
  const [connection, setConnection] = useState<MatchConnectionState>('stable');
  const [gameplayProfileId, setGameplayProfileId] = useState(result.gameplayDna?.primaryProfileId ?? 'MAIN');
  const [secondHalfDrop, setSecondHalfDrop] = useState(false);
  const [metrics, setMetrics] = useState<MatchPerformanceMetrics>(EMPTY_METRICS);
  const [testedOptionKey, setTestedOptionKey] = useState('');
  const [controlStyle, setControlStyle] = useState<ControlStyleV3760>('mixed');
  const [inputDelayRating, setInputDelayRating] = useState<MatchValidationRating>(3);
  const [actionRatingsR461, setActionRatingsR461] = useState<Record<string, MatchValidationRating>>({});
  const [matchSessionIdR462, setMatchSessionIdR462] = useState('');
  const [observedMetricKeysR468, setObservedMetricKeysR468] = useState<Array<keyof MatchPerformanceMetrics>>([]);

  useEffect(() => setRecords(loadRecords()), []);
  useEffect(() => {
    try {
      const key = 'buildmaster-match-session-r462';
      const existing = window.sessionStorage.getItem(key)?.trim();
      const next = existing || createMatchSessionIdR462();
      if (!existing) window.sessionStorage.setItem(key, next);
      setMatchSessionIdR462(next);
    } catch {
      setMatchSessionIdR462((current) => current || createMatchSessionIdR462());
    }
  }, []);
  const startNewMatchSessionR462 = () => {
    const next = createMatchSessionIdR462();
    try { window.sessionStorage.setItem('buildmaster-match-session-r462', next); } catch { /* memória de sessão é opcional */ }
    setMatchSessionIdR462(next);
    setMessage('Nova sessão R462 iniciada. As próximas partidas serão tratadas como uma sessão independente.');
  };
  const fingerprint = cardFingerprint(result);
  const usagePosition = analysisUsagePositionR138(result);
  const currentRecords = useMemo(() => exactUsageMatchValidationRecordsR137(result, records), [records, fingerprint, usagePosition]);
  const summary = useMemo(() => summarizeMatchValidation(currentRecords), [currentRecords]);
  const evidenceLoop = useMemo(() => buildMatchEvidenceLoop(result, records), [result, records]);
  const realValidation = useMemo(() => buildRealValidationV3760(result, records), [result, records]);
  const gameplayValidation = useMemo(() => buildRealGameplayValidationV4050(result, records), [result, records]);
  const longitudinalValidation = useMemo(() => buildLongitudinalGameplayV4060(result, records), [result, records]);
  const matchCalibrationR136 = useMemo(() => buildMatchEvidenceCalibrationR136(result, records), [result, records]);
  const buildOutcomeR460 = useMemo(() => buildBuildOutcomeCalibrationR460(result, records), [result, records]);
  const observedActionsR461 = useMemo(() => {
    const impact = (result as AnalysisResult & { cleanSlate2027R119?: { gameplayImpactR458?: { actions?: Array<{ id:string; label:string; demand:number }> } } }).cleanSlate2027R119?.gameplayImpactR458;
    return [...(impact?.actions ?? [])].filter((action) => Number(action.demand) >= 25).sort((a,b) => Number(b.demand)-Number(a.demand)).slice(0, 4);
  }, [result]);
  const testedOptions = useMemo(() => {
    const boosterName = result.recommendedImpetos[0]?.name || 'Sem Booster confirmado';
    if (gameplayValidation.arms.length > 1) return [...gameplayValidation.arms].sort((a, b) => a.rank - b.rank).map((candidate) => ({
      key: `${candidate.id}::${boosterName}`,
      arm: candidate.rank === 1 ? 'A' as const : candidate.rank === 2 ? 'B' as const : 'NONE' as const,
      buildId: candidate.id,
      buildTitle: candidate.label,
      boosterName
    }));
    return realValidation.experiment.arms.map((arm) => ({ key: `${arm.buildId}::${arm.boosterName}`, arm: arm.arm, buildId: arm.buildId, buildTitle: arm.buildTitle, boosterName: arm.boosterName }));
  }, [gameplayValidation.arms, realValidation.experiment.arms, result.recommendedImpetos]);
  const effectiveTestedOptionKey = testedOptionKey || testedOptions[0]?.key || '';
  const positionMetricFields = useMemo<Array<{ key: keyof MatchPerformanceMetrics; label: string }>>(() => {
    const position = usagePosition;
    if (position === 'GK') return [{ key: 'saves', label: 'Defesas' }, { key: 'goalsConceded', label: 'Gols sofridos' }, { key: 'progressivePasses', label: 'Saídas progressivas' }, { key: 'aerialDuelsWon', label: 'Bolas aéreas dominadas' }];
    if (['CB', 'LB', 'RB'].includes(position)) return [{ key: 'clearances', label: 'Cortes' }, { key: 'blocks', label: 'Bloqueios' }, { key: 'aerialDuelsWon', label: 'Duelos aéreos ganhos' }, { key: 'duelsWon', label: 'Duelos vencidos' }];
    if (['DMF', 'CMF', 'LMF', 'RMF', 'AMF'].includes(position)) return [{ key: 'progressivePasses', label: 'Passes progressivos' }, { key: 'keyPasses', label: 'Passes-chave' }, { key: 'recoveries', label: 'Recuperações' }, { key: 'successfulPressures', label: 'Pressões bem-sucedidas' }];
    return [{ key: 'shotsOnTarget', label: 'Chutes no alvo' }, { key: 'runsBehind', label: 'Desmarques em profundidade' }, { key: 'keyPasses', label: 'Passes-chave' }, { key: 'successfulPressures', label: 'Pressões bem-sucedidas' }];
  }, [usagePosition]);

  const persist = (next: MatchValidationRecord[]) => {
    const storage = persistMatchValidationRepositoryR137(next, { source: 'match-validation-center' });
    if (!storage.persisted) {
      setMessage('Não foi possível salvar o histórico de partidas nesta conta. Nenhuma memória derivada foi atualizada.');
      return false;
    }
    const safe = storage.records;
    setRecords(safe);
    const profile = buildRealValidationV3760(result, safe).userLearning;
    writeAccountStorage(REAL_VALIDATION_PROFILE_STORAGE_KEY, JSON.stringify(profile));
    const gameplay = buildRealGameplayValidationV4050(result, safe);
    persistVerifiedGameplayWinnerV4050(result, gameplay);
    const longitudinal = buildLongitudinalGameplayV4060(result, safe);
    persistLongitudinalWinnerV4060(result, longitudinal);
    return true;
  };

  const save = () => {
    const testedOption = testedOptions.find((option) => option.key === effectiveTestedOptionKey) ?? testedOptions[0];
    const record = createMatchValidationRecord(result, {
      minutes: Math.max(1, Math.min(130, minutes)),
      overallRating,
      passing,
      movement,
      finishing,
      defending,
      physical,
      stamina,
      tags,
      note: note.trim(),
      mode,
      connection,
      gameplayProfileId,
      secondHalfDrop,
      metrics,
      testedBuildId: testedOption?.buildId,
      testedBuildTitle: testedOption?.buildTitle,
      testedBoosterName: testedOption?.boosterName,
      experimentArm: testedOption?.arm ?? 'NONE',
      controlStyle,
      inputDelayRating,
      actionRatingsR461: Object.keys(actionRatingsR461).length ? actionRatingsR461 : undefined,
      sessionIdR462: matchSessionIdR462 || undefined,
      observedMetricKeysR468: observedMetricKeysR468.length ? observedMetricKeysR468 : undefined
    });
    if (!persist([record, ...records])) return;
    setTags([]);
    setNote('');
    setSecondHalfDrop(false);
    setMetrics(EMPTY_METRICS);
    setActionRatingsR461({});
    setObservedMetricKeysR468([]);
    setMessage(`Partida registrada com snapshot R460 e evidência por ação R461. Esta ficha agora possui ${currentRecords.length + 1} avaliação(ões). R136/R460 só recalibram o Clean Slate após repetição recente, contextual e confiável suficiente.`);
  };

  const reset = () => {
    if (!persist(removeUsageMatchValidationRecordsR137(result, records))) return;
    setMessage(`Histórico desta carta em ${usagePosition} removido. Partidas da mesma edição em outras posições foram preservadas.`);
  };

  return <div className="result-section-grid match-validation-center">
    <LongitudinalGameplayV4060Panel analysis={longitudinalValidation} />
    <RealGameplayValidationV4050Panel analysis={gameplayValidation} />
    <RealValidationV3760Panel analysis={realValidation} />
    <article className="luxury-panel wide-card">
      <div className="section-title-row"><div><p className="kicker"><Activity size={14}/> Calibração temporal/contextual R136</p><h3>Partidas reais como evidência, não como receita</h3></div><span>{matchCalibrationR136.status}</span></div>
      <div className="match-validation-verdict professional-evidence-verdict"><CheckCircle2 size={20}/><div><strong>{matchCalibrationR136.rawMatches} partida(s) • {matchCalibrationR136.distinctSessions} sessão(ões) • confiança {matchCalibrationR136.confidenceScore}/100</strong><span>{matchCalibrationR136.reasons[1] || matchCalibrationR136.reasons[0]}</span><small>Força atual: {Math.round(matchCalibrationR136.calibrationStrength * 100)}% • recência {matchCalibrationR136.recencyScore}/100 • contexto v6.0 {matchCalibrationR136.currentPatchShare}%. O Clean Slate continua sendo o único escritor da ficha.</small></div></div>
    </article>
    <article className="luxury-panel wide-card">
      <div className="section-title-row"><div><p className="kicker"><Activity size={14}/> Aprendizado promessa × resultado R460</p><h3>A ficha melhora o que prometeu?</h3></div><span>{buildOutcomeR460.status}</span></div>
      <div className="match-validation-verdict professional-evidence-verdict"><CheckCircle2 size={20}/><div><strong>{buildOutcomeR460.snapshotMatches} partida(s) com snapshot • {buildOutcomeR460.distinctSessions} sessão(ões) • confiança {buildOutcomeR460.confidenceScore}/100 • ação direta {buildOutcomeR460.directActionEvidenceRate}%</strong><span>{buildOutcomeR460.reasons[1] || buildOutcomeR460.reasons[0]}</span><small>Função isolada: {buildOutcomeR460.usageFunction}. {buildOutcomeR460.mismatchedFunctionMatches ? `${buildOutcomeR460.mismatchedFunctionMatches} partida(s) de outra função foram separadas.` : 'Nenhuma evidência de outra função foi misturada.'}</small></div></div>
      {buildOutcomeR460.actions.length > 0 && <div className="match-area-summary"><div><strong>Ações acompanhadas</strong>{buildOutcomeR460.actions.slice(0,4).map((action) => <span key={action.id}>{action.label} • observado {Math.round(action.observedScore)}/100 • {action.status}</span>)}</div><div><strong>Reforço aprendido</strong>{buildOutcomeR460.actions.filter((action) => action.learningMultiplier > 1).slice(0,4).map((action) => <span key={action.id}>{action.label} ×{action.learningMultiplier.toFixed(3)}</span>)}{!buildOutcomeR460.actions.some((action) => action.learningMultiplier > 1) && <span>Nenhuma ação recebeu pressão extra.</span>}</div></div>}
    </article>
    <article className="luxury-panel wide-card">
      <div className="section-title-row"><div><p className="kicker"><Target size={14}/> Validação em partidas</p><h3>Teste a ficha sem alterar a recomendação original</h3></div><span>{summary.totalMatches} partida(s)</span></div>
      <div className="health-score-grid match-summary-grid">
        <article><strong>{summary.average || '—'}</strong><span>Média geral</span><small>de 5</small></article>
        <article><strong>{summary.consistency || '—'}</strong><span>Consistência</span><small>de 100</small></article>
        <article><strong>{summary.confidence}</strong><span>Confiança</span><small>da amostra</small></article>
        <article><strong>{summary.totalMatches}</strong><span>Partidas</span><small>mesma carta • mesma posição</small></article>
      </div>
      <div className="match-validation-verdict"><CheckCircle2 size={20}/><div><strong>Leitura do histórico</strong><span>{summary.recommendation}</span></div></div>
      <div className="match-validation-verdict professional-evidence-verdict"><Activity size={20}/><div><strong>Ciclo profissional • confiança {evidenceLoop.confidence}</strong><span>{evidenceLoop.verdict}</span>{evidenceLoop.correction && <small>{evidenceLoop.correction}</small>}</div></div>
      {(summary.strongestAreas.length > 0 || summary.weakestAreas.length > 0) && <div className="match-area-summary"><div><strong>Melhores áreas</strong>{summary.strongestAreas.map((item) => <span key={item}>{item}</span>)}</div><div><strong>Áreas para observar</strong>{summary.weakestAreas.map((item) => <span key={item}>{item}</span>)}</div></div>}
      {summary.repeatedProblems.length > 0 && <div className="match-repeated-problems"><strong>Padrões repetidos</strong>{summary.repeatedProblems.slice(0, 5).map((item) => <span key={item.tag}>{item.tag} • {item.count} vezes</span>)}</div>}
      {summary.evidence && <div className="professional-match-evidence-grid"><span><b>{summary.evidence.goals}</b> gols</span><span><b>{summary.evidence.assists}</b> assist.</span><span><b>{summary.evidence.dribblesCompleted}</b> dribles</span><span><b>{summary.evidence.interceptions}</b> intercept.</span><span><b>{summary.evidence.passErrors}</b> erros passe</span><span><b>{summary.evidence.ballLosses}</b> perdas</span></div>}
    </article>

    <article className="luxury-panel wide-card">
      <div className="section-title-row"><div><p className="kicker"><Save size={14}/> Registrar nova partida</p><h3>Avalie somente o que você realmente percebeu</h3></div><span>1 = ruim • 5 = ótimo</span></div>
      <div className="professional-match-context-grid">
        <label><span>Modo</span><select value={mode} onChange={(event: ChangeEvent<HTMLSelectElement>) => setMode(event.target.value as MatchValidationMode)}><option value="ranked">Ranqueada</option><option value="events">Eventos</option><option value="friendly">Amistosa</option><option value="offline">Offline</option></select></label>
        <label><span>Conexão</span><select value={connection} onChange={(event: ChangeEvent<HTMLSelectElement>) => setConnection(event.target.value as MatchConnectionState)}><option value="stable">Estável</option><option value="variable">Variável</option><option value="high_delay">Delay alto</option></select></label>
        <label><span>Perfil usado</span><select value={gameplayProfileId} onChange={(event: ChangeEvent<HTMLSelectElement>) => setGameplayProfileId(event.target.value)}>{(result.gameplayDna?.profiles ?? []).map((profile) => <option key={profile.id} value={profile.id}>{profile.label}</option>)}{!result.gameplayDna?.profiles.length && <option value="MAIN">Ficha principal</option>}</select></label>
        <label className="match-minutes-field"><span>Minutos usados</span><input type="number" min={1} max={130} value={minutes} onChange={(event: ChangeEvent<HTMLInputElement>) => setMinutes(Number(event.target.value) || 1)}/></label>
        <label><span>Ficha em teste (v40.60)</span><select value={effectiveTestedOptionKey} onChange={(event: ChangeEvent<HTMLSelectElement>) => setTestedOptionKey(event.target.value)}>{testedOptions.map((option) => <option key={option.key} value={option.key}>{option.arm !== 'NONE' ? `Opção ${option.arm} • ` : ''}{option.buildTitle} • {option.boosterName}</option>)}</select></label>
        <label><span>Estilo de controle</span><select value={controlStyle} onChange={(event: ChangeEvent<HTMLSelectElement>) => setControlStyle(event.target.value as ControlStyleV3760)}><option value="quick-pass">Toques e passes rápidos</option><option value="carry-dribble">Condução e drible</option><option value="mixed">Misto e adaptável</option><option value="manual-defense">Defesa e marcação manual</option></select></label>
        <label><span>Delay percebido</span><select value={inputDelayRating} onChange={(event: ChangeEvent<HTMLSelectElement>) => setInputDelayRating(Number(event.target.value) as MatchValidationRating)}>{RATING_OPTIONS.map((rating) => <option key={rating} value={rating}>{rating} — {rating <= 2 ? 'baixo' : rating === 3 ? 'médio' : 'alto'}</option>)}</select></label>
      </div>
      <div className="match-validation-verdict professional-evidence-verdict"><History size={20}/><div><strong>Sessão R462 • {matchSessionIdR462 ? matchSessionIdR462.slice(-8) : 'iniciando'}</strong><span>Partidas desta sequência compartilham a mesma sessão. Use “Nova sessão” somente quando começar outro bloco real de jogos.</span><small>Isso impede que várias partidas do mesmo dia sejam confundidas com uma única sessão ou contem como sessões independentes sem motivo.</small></div><button type="button" onClick={startNewMatchSessionR462}>Nova sessão</button></div>
      <div className="match-rating-grid">
        <RatingField label="Avaliação geral" value={overallRating} onChange={setOverallRating}/>
        <RatingField label="Passe" value={passing} onChange={setPassing}/>
        <RatingField label="Movimentação" value={movement} onChange={setMovement}/>
        <RatingField label="Finalização" value={finishing} onChange={setFinishing}/>
        <RatingField label="Defesa" value={defending} onChange={setDefending}/>
        <RatingField label="Físico" value={physical} onChange={setPhysical}/>
        <RatingField label="Resistência" value={stamina} onChange={setStamina}/>
      </div>
      {observedActionsR461.length > 0 && <><div className="section-title-row compact-professional-title"><div><p className="kicker">Evidência direta R461</p><h3>Como as ações principais funcionaram?</h3></div><span>opcional • — = não observei</span></div><div className="match-rating-grid">{observedActionsR461.map((action) => <OptionalActionRatingField key={action.id} label={`${action.label} • demanda ${Math.round(action.demand)}%`} value={actionRatingsR461[action.id]} onChange={(value) => setActionRatingsR461((current) => { const next={...current}; if(value == null) delete next[action.id]; else next[action.id]=value; return next; })}/>)}</div></>}
      <div className="section-title-row compact-professional-title"><div><p className="kicker">Evidência objetiva R468</p><h3>Números da atuação</h3></div><span>opcional • zero digitado conta como observado</span></div>
      <div className="professional-match-metrics-grid">
        <MetricField label="Gols" value={metrics.goals} onChange={(value) => { setObservedMetricKeysR468((current) => current.includes('goals') ? current : [...current, 'goals']); setMetrics((current) => ({ ...current, goals: value })); }}/>
        <MetricField label="Assistências" value={metrics.assists} onChange={(value) => { setObservedMetricKeysR468((current) => current.includes('assists') ? current : [...current, 'assists']); setMetrics((current) => ({ ...current, assists: value })); }}/>
        <MetricField label="Erros de passe" value={metrics.passErrors} onChange={(value) => { setObservedMetricKeysR468((current) => current.includes('passErrors') ? current : [...current, 'passErrors']); setMetrics((current) => ({ ...current, passErrors: value })); }}/>
        <MetricField label="Desarmes" value={metrics.tackles} onChange={(value) => { setObservedMetricKeysR468((current) => current.includes('tackles') ? current : [...current, 'tackles']); setMetrics((current) => ({ ...current, tackles: value })); }}/>
        <MetricField label="Interceptações" value={metrics.interceptions} onChange={(value) => { setObservedMetricKeysR468((current) => current.includes('interceptions') ? current : [...current, 'interceptions']); setMetrics((current) => ({ ...current, interceptions: value })); }}/>
        <MetricField label="Perdas de bola" value={metrics.ballLosses} onChange={(value) => { setObservedMetricKeysR468((current) => current.includes('ballLosses') ? current : [...current, 'ballLosses']); setMetrics((current) => ({ ...current, ballLosses: value })); }}/>
        <MetricField label="Dribles concluídos" value={metrics.dribblesCompleted} onChange={(value) => { setObservedMetricKeysR468((current) => current.includes('dribblesCompleted') ? current : [...current, 'dribblesCompleted']); setMetrics((current) => ({ ...current, dribblesCompleted: value })); }}/>
        <MetricField label="Finalizações" value={metrics.shots} onChange={(value) => { setObservedMetricKeysR468((current) => current.includes('shots') ? current : [...current, 'shots']); setMetrics((current) => ({ ...current, shots: value })); }}/>
        {positionMetricFields.map((field) => <MetricField key={field.key} label={field.label} value={Number(metrics[field.key] || 0)} onChange={(value) => { setObservedMetricKeysR468((current) => current.includes(field.key) ? current : [...current, field.key]); setMetrics((current) => ({ ...current, [field.key]: value })); }}/>)}
      </div>
      <label className="professional-second-half-toggle"><input type="checkbox" checked={secondHalfDrop} onChange={(event: ChangeEvent<HTMLInputElement>) => setSecondHalfDrop(event.target.checked)}/><span>O desempenho caiu claramente no segundo tempo</span></label>
      <div className="match-tag-picker"><span>O que aconteceu?</span><div>{MATCH_PROBLEM_TAGS.map((tag) => <button type="button" key={tag} className={tags.includes(tag) ? 'selected' : ''} onClick={() => setTags((current) => current.includes(tag) ? current.filter((item) => item !== tag) : [...current, tag])}>{tag}</button>)}</div></div>
      <label className="match-note-field"><span>Observação opcional</span><textarea value={note} onChange={(event: ChangeEvent<HTMLTextAreaElement>) => setNote(event.target.value)} placeholder="Ex.: jogou como VOL pela esquerda contra pressão alta"/></label>
      <div className="match-validation-actions"><button type="button" className="elite-button" onClick={save}><Save size={16}/> Salvar avaliação</button>{currentRecords.length > 0 && <button type="button" onClick={reset}><Trash2 size={16}/> Limpar histórico desta carta</button>}</div>
      {message && <p className="inline-status-message" role="status">{message}</p>}
    </article>

    {currentRecords.length > 0 && <article className="luxury-panel wide-card"><div className="section-title-row"><div><p className="kicker"><History size={14}/> Histórico recente</p><h3>Últimas avaliações desta carta</h3></div><span>{currentRecords.length}</span></div><div className="match-history-list">{currentRecords.slice(0, 8).map((record) => <div key={record.id}><strong>{new Date(record.playedAt).toLocaleDateString('pt-BR')} • nota {record.overallRating}/5</strong><span>{record.minutes} min • {record.testedBuildTitle || record.buildName}{record.experimentArm && record.experimentArm !== 'NONE' ? ` • Opção ${record.experimentArm}` : ''}</span><small>{record.testedBoosterName ? `${record.testedBoosterName} • ` : ''}{record.tags.join(' • ') || 'Sem ocorrência marcada'}</small>{record.note && <em>{record.note}</em>}</div>)}</div></article>}
  </div>;
}
