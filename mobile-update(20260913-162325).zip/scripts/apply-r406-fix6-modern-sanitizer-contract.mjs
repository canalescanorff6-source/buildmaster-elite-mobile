import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';

const TARGET='tests/v40-80-r180-global-final-audit-regression.mjs';
const START='// 1) Sanitizador moderno:';
const END='// 2) O bridge OCR';
const NEW=`// 1) Sanitizador moderno: migrações R404+ podem atualizar a árvore atual,
 // mas patchers históricos r16-r116 nunca podem executar dentro do branch moderno.
const sanitizer = read('scripts/sanitize-update-source.mjs');
const detectIndex = sanitizer.indexOf("BM_R119_CLEAN_SLATE_SINGLE_WRITER");
const modernBranchIndex = sanitizer.indexOf('if(modern){');
const r404Index = sanitizer.indexOf('applyCardDnaBuildDiversityR404(root)');
const modernReturnIndex = sanitizer.indexOf('return {modernTree:true');
const firstHistoricalCall = sanitizer.indexOf('applyPreFinalConfirmationR16(root)');
assert.ok(detectIndex >= 0 && modernBranchIndex > detectIndex && r404Index > modernBranchIndex && modernReturnIndex > r404Index && firstHistoricalCall > modernReturnIndex,
  'R180: detectar árvore r119+ deve preceder migrações modernas e o retorno deve ocorrer antes de qualquer patcher histórico.');
const modernBranch = sanitizer.slice(modernBranchIndex, modernReturnIndex);
assert.match(modernBranch,/applyCardDnaBuildDiversityR404\(root\)/,'R180: migrações modernas explícitas podem evoluir a autoridade r119+.');
assert.doesNotMatch(modernBranch,/applyPreFinalConfirmationR16\(root\)|applyR17RegressionCompatibility\(root\)|applyPreFinalAutofillR20\(root\)|applyCardVisionLineBudgetR22\(root\)|applyUniversalDnaR2[45]\(root\)|applyPreFinalVisualR104\(root\)|applyPreFinalAutoProgressR105\(root\)|applyR109ExtremeCompat\(root\)|applyR11[1456].*?\(root\)/,
  'R180: patchers históricos r16-r116 não podem executar dentro do branch moderno.');
assert.match(sanitizer,/return \{modernTree:true,sourcePatched:/,
  'R180: branch moderno precisa retornar explicitamente antes do caminho legado; sourcePatched pode refletir migrações modernas idempotentes.');

`;

export function applyModernSanitizerContractR406Fix6(rootDirectory=process.cwd()){
  const file=resolve(rootDirectory,TARGET);
  if(!existsSync(file)) throw new Error(`R406-fix6: teste ausente: ${TARGET}`);
  const before=readFileSync(file,'utf8');
  if(before.includes("migrações R404+ podem atualizar a árvore atual")) return {changed:false,path:TARGET};
  const start=before.indexOf(START);
  const end=before.indexOf(END);
  if(start<0 || end<=start) throw new Error('R406-fix6: seção 1 do contrato R180 não encontrada');
  const next=before.slice(0,start)+NEW+before.slice(end);
  writeFileSync(file,next,'utf8');
  return {changed:true,path:TARGET};
}
