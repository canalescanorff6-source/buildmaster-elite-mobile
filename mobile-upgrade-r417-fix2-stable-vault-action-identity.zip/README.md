# R417-fix2

Correção preparada a partir da falha real dos logs de CI da R417-fix1.

## Corrige

- Evita colisão de ações em lote que antes usavam apenas `ids.length`.
- Normaliza IDs com `Set + sort`, tornando a identidade determinística.
- Preserva compatibilidade semântica da exclusão individual com `delete:<id>`.
- Atualiza o contrato histórico R154 para a arquitetura R417.
- Adiciona regressão para impedir retorno de `batch:${action}:${ids.length}`.

## Validações esperadas após aplicar

1. `npm run test:r154`
2. teste R417 (`v40-80-r417-autonomous-card-native-bulk-vault-regression.mjs`)
3. diagnóstico consolidado completo
4. somente depois gerar/publicar APK

Observação: o repositório conectado nesta sessão está com leitura disponível, mas sem permissão de push; por isso o patch foi preparado como artefato aplicável, sem alterar a `main`.
