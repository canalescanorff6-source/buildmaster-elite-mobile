import assert from 'node:assert/strict';
import { transformCardVisionAppR16 } from '../scripts/apply-prefinal-confirmation-r16.mjs';
import { transformPreFinalPrintReferenceR103 } from '../scripts/apply-prefinal-print-reference-r103.mjs';

const cleanSource = `
  const [draftResult, setDraftResult] = useState<AnalysisResult | null>(null);
  const [manualFields, setManualFields] = useState<ManualFields>(emptyManualFields());
      setOcrDone(false); setRawText(''); setResult(null); setDraftResult(null); setManualFields(emptyManualFields()); setManualMode(false);
  function openMainSection(section: MainSection, options: { track?: boolean; skipManualBootstrap?: boolean } = {}) {
      hydrateReviewFields(autoResult);
      setDraftResult(null); setResult(autoResult);
      setStatus(\`OCR v40.70 concluído com \${visionAudit.score}/100. Ficha de Desempenho Máximo gerada automaticamente\${autoWarnings}\${discoveryStatus}.\`);
      reportReaderProgress(100, 'Ficha gerada', 'Leitura concluída sem etapa obrigatória de confirmação.', readerTotal, readerTotal);
) : result ? (            <ResultSafetyBoundary
`;

const r16 = transformCardVisionAppR16(cleanSource);
const output = transformPreFinalPrintReferenceR103(r16);

assert.match(output, /BM_PREFINAL_PRINT_REFERENCE_R103/);
assert.match(output, /Print original da carta/);
assert.match(output, /Confira aqui o nível máximo e os pontos de progresso/);
assert.match(output, /src=\{preview\}/);
assert.match(output, /href=\{preview\}/);
assert.match(output, /objectFit: 'contain'/);
assert.match(output, /print completo usado pelo OCR/);
assert.ok(output.indexOf('Print original da carta') < output.indexOf('Nome do jogador'));
assert.equal(transformPreFinalPrintReferenceR103(output), output, 'r103 precisa ser idempotente');

console.log('r103 aprovada: o print original aparece na tela REAL de Nome/Nível/Progresso.');
