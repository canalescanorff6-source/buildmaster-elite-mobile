import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';

export const PREFINAL_PRINT_REFERENCE_R103_MARKER = 'BM_PREFINAL_PRINT_REFERENCE_R103';

function replaceRequired(source, needle, replacement, label) {
  if (source.includes(PREFINAL_PRINT_REFERENCE_R103_MARKER)) return source;
  if (!source.includes(needle)) {
    throw new Error(`[r103] Não foi possível aplicar ${label}: contrato da tela pré-ficha não encontrado.`);
  }
  return source.replace(needle, replacement);
}

export function transformPreFinalPrintReferenceR103(input) {
  let source = input;
  if (source.includes(PREFINAL_PRINT_REFERENCE_R103_MARKER)) return source;

  const needle = `                <label style={{ display: 'grid', gap: 7 }}>
                  <strong>Nome do jogador</strong>`;

  const replacement = `                {/* ${PREFINAL_PRINT_REFERENCE_R103_MARKER} */}
                {preview ? (
                  <div
                    aria-label="Print original para conferência de nível e progresso"
                    style={{
                      display: 'grid',
                      gap: 10,
                      padding: 12,
                      borderRadius: 16,
                      border: '1px solid rgba(96,165,250,.32)',
                      background: 'rgba(5,15,29,.78)'
                    }}
                  >
                    <div style={{ display: 'grid', gap: 3 }}>
                      <strong>Print original da carta</strong>
                      <span style={{ fontSize: 12, opacity: .72, lineHeight: 1.4 }}>
                        Confira aqui o nível máximo e os pontos de progresso antes de gerar a ficha.
                      </span>
                    </div>
                    <a
                      href={preview}
                      target="_blank"
                      rel="noreferrer"
                      aria-label="Abrir print original em tamanho maior"
                      style={{
                        display: 'block',
                        width: '100%',
                        maxHeight: '42vh',
                        overflow: 'auto',
                        borderRadius: 13,
                        background: '#050b14',
                        border: '1px solid rgba(255,255,255,.08)'
                      }}
                    >
                      <img
                        src={preview}
                        alt="Print original usado na leitura"
                        style={{
                          display: 'block',
                          width: '100%',
                          height: 'auto',
                          maxHeight: '42vh',
                          objectFit: 'contain',
                          objectPosition: 'top center'
                        }}
                      />
                    </a>
                    <small style={{ opacity: .66 }}>
                      Toque no print para abrir maior. A imagem mostrada é o print completo usado pelo OCR.
                    </small>
                  </div>
                ) : (
                  <div
                    role="status"
                    style={{
                      padding: 11,
                      borderRadius: 13,
                      border: '1px solid rgba(245,158,11,.28)',
                      background: 'rgba(120,72,8,.12)',
                      fontSize: 12,
                      lineHeight: 1.45
                    }}
                  >
                    O print original não está mais disponível nesta sessão. Volte à leitura e selecione a imagem novamente.
                  </div>
                )}
                <label style={{ display: 'grid', gap: 7 }}>
                  <strong>Nome do jogador</strong>`;

  return replaceRequired(source, needle, replacement, 'referência visual do print na confirmação final');
}

export function applyPreFinalPrintReferenceR103(rootDirectory = process.cwd()) {
  const target = resolve(rootDirectory, 'src/components/CardVisionApp.tsx');
  if (!existsSync(target)) throw new Error('[r103] CardVisionApp.tsx não encontrado.');
  const original = readFileSync(target, 'utf8');
  const source = transformPreFinalPrintReferenceR103(original);
  if (source === original) {
    console.log('v40.80 r103: print na tela pré-ficha já aplicado.');
    return { changed: false, target };
  }
  writeFileSync(target, source, 'utf8');
  console.log('v40.80 r103 aplicada: print original visível em Nome/Nível/Progresso.');
  return { changed: true, target };
}
